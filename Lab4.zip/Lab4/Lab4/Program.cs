﻿using System;
using System.Runtime.CompilerServices;

namespace Lab4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Input: char program, double amount, int years
            //Output: int sumOfDigits, doubl depreciation
            //Written by: Dilpreet Chinna
            //Written for: Carlos Estoy
            //Section: E01
            //Last Modified Date: 2022-11-05
            char program = ' ';
            double amount = 0;
            int years = 0;
            do
            {
                Console.WriteLine("This program computes deprecitaion using sum-of-years-digits method");
                Console.WriteLine("A. Enter a new amount and number of years");
                Console.WriteLine("B. Display depreciation table");
                Console.WriteLine("Q.Quit");
                program = char.Parse(Console.ReadLine());

            
                if (program == 'a')
                {
                    Console.WriteLine("Enter an amount to be depreciated");
                    amount = double.Parse(Console.ReadLine());

                    Console.WriteLine("Enter the number of years");
                    years = int.Parse(Console.ReadLine());
                }
                if(program == 'b' || (amount == 0 && years == 0))
                {
                    Console.WriteLine("You must enter an amount and number of years...");
                }

                int sum = SumOfDigits(years);
                

                if (program == 'b')
                {
                    
                    for(int i = years; i > 0; i--)
                    {

                        double dep = DisplayDepreciation(amount, i, sum);
                        dep = Math.Round(dep, 2);
                        Console.WriteLine("Year $" +dep);          
                        
                    }
                    
                }


            }
            while (program != 'q');
            if (program == 'q')
            {
                Console.WriteLine("Good-bye and thanks for using the program");
            }


        }       
        public static int SumOfDigits(int years)
        {
            int sum = 0;
            for (int i = 1; i <= years; i++)
            {
                sum += i;
            }


            return sum;
        }
        public static double DisplayDepreciation(double amount, int years, int sum)
        {         
            double depreciation = (years * amount) / sum;          
            return depreciation;

        }
       
    }
}
